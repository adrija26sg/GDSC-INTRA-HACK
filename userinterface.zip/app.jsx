// App.jsx

import React from 'react';
import './styles.css'; // Import the external CSS file

const App = () => {
  const selectType = (type) => {
    alert('You selected: ' + type);
    // Add any other logic or actions you want to perform based on the selection
  };

  return (
    <>
      <header>
        <h1>Carbonpal - Your Carbon Footprint Advisor</h1>
      </header>

      <div className="video-container">
        <video autoPlay muted loop id="background-video">
          <source src="./assets/video (2160p).mp4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>

        <button className="button" onClick={() => selectType('individual')}>
          <h2>For individuals</h2>
        </button>
        <button className="button" onClick={() => selectType('business')}>
          <h2>For businesses</h2>
        </button>
      </div>
    </>
  );
};

export default App;
