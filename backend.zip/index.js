const express = require('express');
const axios = require('axios');
const mongoose = require('mongoose');
const mysql = require('mysql2/promise');

const app = express();
const PORT = process.env.PORT || 5000;

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/your-database', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const db = mongoose.connection;

// MySQL Connection wale jo details hai wo apne device ke mysql ke according daaldena
const mysqlConnection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'mysql',
  database: 'carbon_footprint_db',
});

// Express Middleware and Routes
app.use(express.json());

//  route for Carbon Footprint API
app.get('/api/carbon_footprint', async (req, res) => {
  try {
    const response = await axios.get('isme Carbon Footprint API endpoint ayega');
    const data = response.data;

    // Store data in MongoDB
    const carbonFootprintModel = mongoose.model('CarbonFootprint', {
      category: String,
      emissions: Number,
    });
    await carbonFootprintModel.create(data);

    // Store data in MySQL
    await mysqlConnection.execute(
      'INSERT INTO carbon_footprint_data (category, emissions) VALUES (?, ?)',
      [data.category, data.emissions]
    );

    res.json(data);
  } catch (error) {
    console.error('Error fetching carbon footprint data:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

//  route for AirVisual API
app.get('/api/air_quality', async (req, res) => {
  try {
    const response = await axios.get('isme AirVisual API endpoint ayega');
    const data = response.data;

    // Store data in MongoDB
    const airQualityModel = mongoose.model('AirQuality', {
      stationName: String,
      airQualityIndex: Number,
    });
    await airQualityModel.create(data);

    // Store data in MySQL
    await mysqlConnection.execute(
      'INSERT INTO air_quality_data (station_name, air_quality_index) VALUES (?, ?)',
      [data.stationName, data.airQualityIndex]
    );

    res.json(data);
  } catch (error) {
    console.error('Error fetching air quality data:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Example route for Carbon Interface API
app.get('/api/carbon_emissions', async (req, res) => {
  try {
    const response = await axios.get('isme Carbon Interface API endpoint ayega');
    const data = response.data;

    // Store data in MongoDB
    const carbonEmissionsModel = mongoose.model('CarbonEmissions', {
      activity: String,
      emissions: Number,
    });
    await carbonEmissionsModel.create(data);

    // Store data in MySQL
    await mysqlConnection.execute(
      'INSERT INTO carbon_emissions_data (activity, emissions) VALUES (?, ?)',
      [data.activity, data.emissions]
    );

    res.json(data);
  } catch (error) {
    console.error('Error fetching carbon emissions data:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Example route for Cloverly API
app.get('/api/cloverly', async (req, res) => {
  try {
    const response = await axios.get('Cloverly API URL');
    const data = response.data;

    // Store data in MongoDB
    const cloverlyModel = mongoose.model('Cloverly', {
      activity: String,
      offsetAmount: Number,
    });
    await cloverlyModel.create(data);

    // Store data in MySQL
    await mysqlConnection.execute(
      'INSERT INTO cloverly_data (activity, offset_amount) VALUES (?, ?)',
      [data.activity, data.offsetAmount]
    );

    res.json(data);
  } catch (error) {
    console.error('Error fetching Cloverly data:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Start Express server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});