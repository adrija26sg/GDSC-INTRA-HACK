const express = require('express');
const axios = require('axios');
const mysql = require('mysql2/promise');

const app = express();
const PORT = process.env.PORT || 5000;

// MySQL Connection
const mysqlConnection = mysql.createConnection({
  host: 'localhost',
  user: 'your_username',
  password: 'your_password',
  database: 'carbon_footprint_db',
});

// Carbon Footprint API Key
const carbonFootprintApiKey = 'f4a3f736-6bf5-49b1-91f0-c8b1cfd99c32';

// Express Middleware and Routes
app.use(express.json());

app.get('/api/carbon_footprint', async (req, res) => {
  try {
    // Make request to Carbon Footprint API with API key
    const response = await axios.get('https://www.iqair.com/dashboard/api', {
      headers: {
        Authorization: Bearer ${carbonFootprintApiKey}, // Fix the string interpolation
      },
    });

    const data = response.data;

    // Store data in MySQL
    await mysqlConnection.execute(
      'INSERT INTO carbon_footprint_data (category, emissions) VALUES (?, ?)',
      [data.category, data.emissions]
    );

    res.json(data);
  } catch (error) {
    console.error('Error fetching carbon footprint data:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(PORT, () => {
  console.log(Server is running on port ${PORT}); // Fix the string interpolation
});